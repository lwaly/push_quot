#!/bin/bash

WORK_PATH=`dirname $0`
SCRIPT_NAME=`basename $0`
cd ${WORK_PATH}
WORK_PATH=`pwd`

LOG_FILE="${WORK_PATH}/log/${SCRIPT_NAME}.log"


. ${WORK_PATH}/scripts/im_script_func.sh

function start_redis()
{
    local redis_server_bin=$1
    local redis_conf=$2
    debug_log "${redis_server_bin} $redis_conf"
    ${redis_server_bin} ${redis_conf}
}

redis_conf_files=`ls ${WORK_PATH}/conf/redis_*.conf`
for redis_conf in $redis_conf_files
do
    pid_file=`awk '/^pidfile/{print $2}' $redis_conf`
    if [ -f "$pid_file" ]
    then
        redis_pid=`cat $pid_file`
        running_redis_pid=`ps -ef | grep -w "$redis_pid" | awk '/redis/{print $2}'`
        if [ -z "$running_redis_pid" ]
        then
            start_redis ${WORK_PATH}/bin/redis-server $redis_conf
            if [ $? -eq 0 ]
            then
                info_log "${WORK_PATH}/bin/redis-server $redis_conf start successfully."
            else
                error_log "failed to start $redis_conf"
            fi
        else
            warn_log "the redis process for $redis_conf was exist!"
        fi
    else
        start_redis ${WORK_PATH}/bin/redis-server $redis_conf
        if [ $? -eq 0 ]
        then
            info_log "${WORK_PATH}/bin/redis-server $redis_conf start successfully."
        else
            error_log "failed to start $redis_conf"
        fi
    fi
done


